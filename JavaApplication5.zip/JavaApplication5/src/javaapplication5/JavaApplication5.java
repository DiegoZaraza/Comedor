/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

/**
 *
 * @author e10417a
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(metodo(5));
    }

    public static String metodoraro() {
        int[] lista = {8, 9, 3};

        int n = lista.length;
        String[] simbolo = new String[n];

        int i, j, aux, izq, der, m;

        for (i = 1; i < n; i++) {
            aux = lista[i];
            izq = 0;
            der = i - 1;

            while (izq <= der) {
                m = ((izq + der) / 2);
                if (aux < lista[m]) {
                    der = m - 1;
                    simbolo[i - 1] = "-";
                } else {
                    izq = m + 1;
                    simbolo[i - 1] = "+";

                }
            }

            j = i - 1;
            while (j >= izq) {
                lista[j + 1] = lista[j];
                j = j - 1;
            }
            lista[izq] = aux;
        }
        simbolo[i - 1] = "$";
        String salida = "";
        for (i = 0; i < n; i++) {
            salida += lista[i] + simbolo[i];
        }
        return salida;
    }
    
    public static int metodo(int valor){
        if(valor <3){
            return valor;
        }
        
        return metodo(valor - 1) * metodo(valor - 2);
    }
}