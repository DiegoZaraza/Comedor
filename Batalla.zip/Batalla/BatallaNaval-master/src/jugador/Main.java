package jugador;

import javax.swing.*;

import java.awt.*;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class Main extends JFrame {

	private Cliente cliente;

	private JPanel jPanelJugador;
	private JPanel jPanelRival;
	private JLabel jLblJugador[][];
	private JLabel jLblRival[][];
	private JLabel letras[];
	private JLabel jLblConexion;
	private JLabel jLblCoordenadas;
	private JButton jBtnComenzar;
	private JButton jBtnFuego;
	private JButton jBtnSalir;
	private JTextField jTxtDisparar;
	private JPanel jPanelControles;

	public Main() {
		// Solicitar Datos de la Conexion
		String puert = JOptionPane.showInputDialog("Puerto", "");
		String h = JOptionPane.showInputDialog("Host", "");
		int p = Integer.parseInt(puert);

		cliente = new Cliente(this, h, p);

		jPanelJugador = new JPanel();
		jPanelJugador.setBorder(new LineBorder(new Color(0, 0, 0)));
		jPanelJugador.setLocation(22, 31);
		jPanelJugador.setSize(370, 344);

		jPanelRival = new JPanel();
		jPanelRival.setBorder(new LineBorder(new Color(0, 0, 0)));
		jPanelRival.setLocation(442, 31);
		jPanelRival.setSize(370, 344);
		
		jPanelControles = new JPanel();
		jPanelControles.setBorder(new LineBorder(new Color(0, 0, 0)));
		jPanelControles.setBounds(22, 386, 790, 74);
		
		getContentPane().add(jPanelControles);
		
		jPanelControles.setLayout(null);
		jBtnComenzar = new JButton();
		jBtnComenzar.setBounds(10, 26, 102, 23);
		jPanelControles.add(jBtnComenzar);

		// Boton de Comenzar Para Posicionar los Barcos
		jBtnComenzar.setText("Comenzar");
		jBtnComenzar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JBtnComenzarActionPerformed(evt);
			}
		});
		jLblConexion = new JLabel("_______________TABLERO RIVAL______________");
		jLblConexion.setBounds(331, 28, 100, 21);
		jPanelControles.add(jLblConexion);

		// ID CLIENTE
		jLblConexion.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
		jLblConexion.setText("No Conectado");

		// Botones y Etiquetas Para Disparar
		jLblCoordenadas = new JLabel("Coordenadas Disparo (EJ: k3)");
		jLblCoordenadas.setBounds(515, 11, 143, 14);
		jPanelControles.add(jLblCoordenadas);
		jTxtDisparar = new JTextField();
		jTxtDisparar.setBounds(515, 33, 143, 20);
		jPanelControles.add(jTxtDisparar);

		// jBtnFuego.setEnabled(false);
		jBtnFuego = new JButton();
		jBtnFuego.setBounds(668, 30, 100, 23);
		jPanelControles.add(jBtnFuego);

		jBtnFuego.setText("Fuego !!");
		jBtnSalir = new JButton();
		jBtnSalir.setBounds(145, 26, 100, 23);
		jPanelControles.add(jBtnSalir);

		// BOTON SALIR
		jBtnSalir.setText("Salir");
		jBtnSalir.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JB3ActionPerformed(evt);
			}
		});
		jBtnFuego.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JB2ActionPerformed(evt);
			}
		});

		dibujarGUI();
		init();
		
		Thread hilo = new Thread(cliente);
		hilo.start();
	}

	// GETs Para Modificar la Interfaz Desde el Cliente
	public JButton getJBtnComenzar() {
		return jBtnComenzar;
	}

	public JButton getJBtnFuego() {
		return jBtnFuego;
	}

	public JLabel[][] getJLblJugador() {
		return jLblJugador;
	}

	public JLabel[][] getJLblRival() {
		return jLblRival;
	}

	public void init() {
		setSize(850, 500);
		setTitle("Batalla Naval");
		setResizable(false);
		setDefaultCloseOperation(0);
	}

	// DIBUJAR INTERFAZ COMPLETA
	public void dibujarGUI() {
		jLblJugador = new JLabel[10][10];
		jLblRival = new JLabel[10][10];
		letras = new JLabel[10];
		String dicc = "ABCDEFGHIJ";

		int y = 60;
		for (int i = 0; i < 10; i++) {
			// LETRAS
			String L = dicc.substring(i, i + 1);

			letras[i] = new JLabel(L);
			letras[i].setBounds(40, y, 30, 30);
			jPanelJugador.add(letras[i]);

			letras[i] = new JLabel(L);
			letras[i].setBounds(40, y, 30, 30);
			jPanelRival.add(letras[i]);

			// NUMEROS
//			String n = Integer.toString(i + 1);
//
//			numeros[i] = new JLabel(n);
//			numeros[i].setBounds(num += 32, 30, 30, 30);
//			jPanelJugador.add(numeros[i]);
//
//			numeros[i] = new JLabel(n);
//			numeros[i].setBounds(num, 30, 30, 30);
//			jPanelRival.add(numeros[i]);

//			// TABLEROS
//			for (int j = 0; j < 10; j++) {
//				jLblJugador[i][j] = new JLabel("");
//				jLblJugador[i][j].setBounds(x, y, 30, 30);
//				jLblJugador[i][j].setBackground(Color.WHITE);
//				jLblJugador[i][j].setOpaque(true);
//				jLblJugador[i][j].setVisible(true);
//				jPanelJugador.add(jLblJugador[i][j]);
//
//				jLblRival[i][j] = new JLabel("");
//				jLblRival[i][j].setBounds(x, y, 30, 30);
//				jLblRival[i][j].setBackground(Color.WHITE);
//				jLblRival[i][j].setOpaque(true);
//				jPanelRival.add(jLblRival[i][j]);
//				x += 32;
//			}
			y += 32;
		}

		// // BORDES TITULOS
		// int f1 = 324;
		// for (int i = 0; i < 33; i++) {
		// jLblConexion = new JLabel("_");
		// jLblConexion.setBounds(f1, 10, 100, 28);
		// jPanelJugador.add(jLblConexion);
		// f1 += 7;
		// }
		//
		// int f2 = -12;
		// for (int i = 0; i < 3; i++) {
		// jLblConexion = new JLabel("|");
		// jLblConexion.setBounds(322, f2, 100, 28);
		// jPanelJugador.add(jLblConexion);
		//
		// jLblConexion = new JLabel("|");
		// jLblConexion.setBounds(553, f2, 100, 28);
		// jPanelJugador.add(jLblConexion);
		// f2 += 11;
		// }
		//
		// int f3 = 22;
		// for (int i = 0; i < 61; i++) {
		// jLblConexion = new JLabel("_");
		// jLblConexion.setBounds(f3, 314, 200, 100);
		// jPanelJugador.add(jLblConexion);
		// f3 += 7;
		// }
		//
		// // BORDES VERTICAL
		// int v = 30;
		// for (int i = 0; i < 22; i++) {
		// jLblConexion = new JLabel("|");
		// jLblConexion.setBounds(103, v, 200, 100);
		// jPanelJugador.add(jLblConexion);
		//
		// jLblConexion = new JLabel("|");
		// jLblConexion.setBounds(473, v, 200, 100);
		// jPanelJugador.add(jLblConexion);
		// v += 11;
		// }
		//
		// // BORDES DE LOS BOTONES
		// int b1 = 325;
		// for (int i = 0; i < 8; i++) {
		// jLblConexion = new JLabel("|");
		// jLblConexion.setBounds(473, b1, 200, 100);
		// jPanelJugador.add(jLblConexion);
		// b1 += 11;
		// }
		//
		// int b2 = 474;
		// for (int i = 0; i < 50; i++) {
		// jLblConexion = new JLabel("_");
		// jLblConexion.setBounds(b2, 314, 200, 100);
		// jPanelJugador.add(jLblConexion);
		// b2 += 7;
		// }
		getContentPane().setLayout(null);
		getContentPane().add(jPanelJugador);
		getContentPane().add(jPanelRival);
	}

	// POSICIONAR BARCOS
	private void JBtnComenzarActionPerformed(java.awt.event.ActionEvent evt) {
		boolean flag = false;
		while (flag == false) { // portaaviones
			flag = Barco("5");
		}

		boolean flag2 = false;
		while (flag2 == false) { // acorazado
			flag2 = Barco("4");
		}

		boolean flag3 = false;
		while (flag3 == false) { // submarino
			flag3 = Barco("3");
		}

		boolean flag4 = false;
		while (flag4 == false) { // submarino
			flag4 = Barco("3");
		}

		boolean flag5 = false;
		while (flag5 == false) { // destructor
			flag5 = Barco("2");
		}

		boolean flag6 = false;
		while (flag6 == false) { // destructor
			flag6 = Barco("2");
		}

		jBtnComenzar.setEnabled(false);
		jBtnFuego.setEnabled(true);
	}

	// Metodo para Posicionar cada Barco
	public boolean Barco(String casilleros) {
		boolean flag = false;
		String cant = casilleros;

		int cas = Integer.parseInt(casilleros);
		int hv = 0;

		String coordenada = "";
		String verhor = "";

		switch (cas) {
		case 5: {
			String b = JOptionPane.showInputDialog("portaaviones (4 espacios)", "");
			int direcc = JOptionPane.showOptionDialog(null, "Direccion", "Horizontal o Vertival?",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] { "Horizontal", "Vertical" },
					"H");
			hv = direcc;
			coordenada = b;
		}
			break;
		case 4: {
			String b = JOptionPane.showInputDialog("acorazado (4 espacios)", "");
			int direcc = JOptionPane.showOptionDialog(null, "Seleccione Direccion", "�Vertical u Horizontal?",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] { "H", "V" },
					"H");
			hv = direcc;
			coordenada = b;
		}
			break;
		case 3: {
			String b = JOptionPane.showInputDialog("submarino (3 espacios)", "");
			int direcc = JOptionPane.showOptionDialog(null, "Seleccione Direccion", "�Vertical u Horizontal?",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] { "H", "V" },
					"H");
			hv = direcc;
			coordenada = b;
		}
			break;
		case 2: {
			String b = JOptionPane.showInputDialog("destructor (2 espacios)", "");
			int direcc = JOptionPane.showOptionDialog(null, "Seleccione Direccion", "�Vertical u Horizontal?",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] { "H", "V" },
					"H");
			hv = direcc;
			coordenada = b;
		}
			break;
		}

		if (hv == 0) {
			verhor = "H";
		}
		if (hv == 1) {
			verhor = "V";
		}

		try {
			if ((coordenada != null) && (verhor != null)) {
				int aux1 = letraXNumero(coordenada.substring(0, 1)) - 1;
				String f = String.format("%02d", aux1);

				int max = coordenada.length();
				int aux2 = Integer.parseInt(coordenada.substring(1, max)) - 1;
				String c = String.format("%02d", aux2);

				// Si las Posiciones no son Validas el Mensaje no se Envia y
				// Solicita las Coordenadas
				// Del Barco otra vez.
				if (cliente.revisarTablero(f, c, verhor, cant) == true) {
					flag = true;
					cliente.enviarMsjPos(f, c, verhor, cant);
				} else {
					flag = false;
					JOptionPane.showMessageDialog(null, "ERROR Tablero", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "ERROR", "ERROR", JOptionPane.ERROR_MESSAGE);
		}

		return flag;
	}

	// BOTON DISPARAR
	private void JB2ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			String coordenada = jTxtDisparar.getText();

			if (coordenada != null) {

				int aux1 = letraXNumero(coordenada.substring(0, 1)) - 1; // Letra
				String f = String.format("%02d", aux1);

				int max = coordenada.length();
				int aux2 = Integer.parseInt(coordenada.substring(1, max)) - 1; // Numero
				String c = String.format("%02d", aux2);

				cliente.enviarMsjDis(f, c);
			} else {
				JOptionPane.showMessageDialog(null, "Error Disparo", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error Disparo", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void JB3ActionPerformed(java.awt.event.ActionEvent evt) {
		System.exit(0);
	}

	/*
	 * private void JB4ActionPerformed(ActionEvent evt) { DireccionesIP
	 * irinfo=new DireccionesIP(); irinfo.setVisible(true); }
	 */
	public int letraXNumero(String letra) {
		String ABC = "ABCDEFGHIJKL";
		String abc = "abcdefghijkl";
		boolean flag = false;
		char l = letra.charAt(0);
		int i = 0;

		while ((flag == false) && (i < 25)) {
			if ((abc.charAt(i) == l) || (ABC.charAt(i) == l)) {
				flag = true;
			}
			i++;
		}
		return i;
	}

	public void cambioTexto(String cad) {
		jLblConexion.setText(cad);
	}

	public static void main(String args[]) {
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Main().setVisible(true);
			}
		});
	}
}
