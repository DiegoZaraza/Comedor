/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentacion.Controller;

import Presentacion.View.traslados;

/**
 *
 * @author Estudiantes
 */
public class trasladosController {

    private final traslados ventana;
    
    public trasladosController(traslados aThis) {
       ventana = aThis;
    }
    
}
