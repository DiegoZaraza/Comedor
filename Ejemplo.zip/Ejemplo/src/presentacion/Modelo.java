/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presentacion;

import logica.Calculadora;

/**
 *
 * @author Estudiantes
 */
public class Modelo {

    private Calculadora sistema;
    private Vista ventanaPrincipal;

    public Calculadora getSistema() {
        if(sistema == null){
            sistema = new Calculadora();
        }
        return sistema;
    }      

    public Vista getVentanaPrincipal() {
        if(ventanaPrincipal == null){
            ventanaPrincipal = new Vista(this);
        }
        return ventanaPrincipal;
    }
    
    
    public void iniciar() {
        getVentanaPrincipal().setSize(400, 400);
        getVentanaPrincipal().setVisible(true);
    }
    
    public void funcionalidadSumar(){
        
        float n1, n2, r = 0;
        boolean error = false;

        try{
            n1 = Float.parseFloat(getVentanaPrincipal().getTxtNumero1().getText());
            n2 = Float.parseFloat(getVentanaPrincipal().getTxtNumero2().getText());
        
            getSistema().setNumero1(n1);
            getSistema().setNumero2(n2);

            r = getSistema().sumar();
        }catch(NumberFormatException e){
            error = true;
        }
        
        if(error){
            getVentanaPrincipal().getLblResultado().setText("Error en la entrada de datos");
        }else{
            getVentanaPrincipal().getLblResultado().setText("El resultado de la suma es: " + r);
        }
    }
}
