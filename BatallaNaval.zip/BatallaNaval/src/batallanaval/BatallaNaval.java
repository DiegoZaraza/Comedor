/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package batallanaval;

import Cliente.Tablero;

/**
 *
 * @author e10417a
 */
public class BatallaNaval {

    private Tablero miApp;
    
    public BatallaNaval() {
        miApp = new Tablero();
        miApp.dibujarGUI();
        miApp.setVisible(true);
    }
    
    public static void main(String[] args) {
        BatallaNaval batalla = new BatallaNaval();
    }  
}
