/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import logica.vo.ProcesosVo;
import persistencia.Conexion;

/**
 *
 * @author e10417a
 */
public class ProcesoDao {

    public ArrayList<ProcesosVo> datosGraficoCuentas() {
        Conexion conex = new Conexion();
        ArrayList<ProcesosVo> retorno = new ArrayList<>();
        boolean existe = false;

        try {
            //Statement estatuto = conex.getConnection().createStatement();
            PreparedStatement consulta = conex.getConnection().prepareStatement("SELECT U.NamCuenta as NombreCuenta, T.NamTipoCat as Tipo,SUM(M.ValorMov) as Valor FROM MOVIMIENTOS M, CATEGORIAS C, CUENTAS U, TIPOCAT T WHERE C.IdCategoria = M.IdCategoria AND U.IdCuenta = M.IdCuenta AND T.IdTipoCat = C.IdTipoCategoria GROUP BY M.IdCuenta, C.IdTipoCategoria");

            ResultSet res = consulta.executeQuery();
            while (res.next()) {
                ProcesosVo pro = new ProcesosVo();
                pro.setCuenta(res.getString("NombreCuenta"));
                pro.setTipo(res.getString("Tipo"));
                pro.setValor(res.getInt("Valor"));
                retorno.add(pro);
            }
            res.close();
            conex.desconectar();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, no se conecto");
            System.out.println(e);
        }
        return retorno;
    }

    public ArrayList<ProcesosVo> datosGraficoCategoria() {
        Conexion conex = new Conexion();
        ArrayList<ProcesosVo> retorno = new ArrayList<>();

        try {
            //Statement estatuto = conex.getConnection().createStatement();
            PreparedStatement consulta = conex.getConnection().prepareStatement("SELECT C.NamCategoria as NomCat, T.NamTipoCat as Tipo,SUM(M.ValorMov) as Valor FROM MOVIMIENTOS M,CATEGORIAS C, CUENTAS U, TIPOCAT T WHERE C.IdCategoria = M.IdCategoria AND U.IdCuenta = M.IdCuenta AND T.IdTipoCat = C.IdTipoCategoria GROUP BY C.IdCategoria;");

            ResultSet res = consulta.executeQuery();
            while (res.next()) {
                ProcesosVo pro = new ProcesosVo();
                pro.setCuenta(res.getString("NomCat"));
                pro.setTipo(res.getString("Tipo"));
                pro.setValor(res.getInt("Valor"));
                retorno.add(pro);
            }
            res.close();
            conex.desconectar();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, no se conecto");
            System.out.println(e);
        }
        return retorno;
    }

    public ArrayList<ProcesosVo> datosIngreso() {
        Conexion conex = new Conexion();
        ArrayList<ProcesosVo> retorno = new ArrayList<>();

        try {
            //Statement estatuto = conex.getConnection().createStatement();
            PreparedStatement consulta = conex.getConnection().prepareStatement("SELECT T.NamTipoCat as Tipo,SUM(M.ValorMov) as Valor FROM MOVIMIENTOS M,CATEGORIAS C, TIPOCAT T WHERE C.IdCategoria = M.IdCategoria AND T.IdTipoCat = C.IdTipoCategoria GROUP BY C.IdTipoCategoria;");

            ResultSet res = consulta.executeQuery();
            while (res.next()) {
                ProcesosVo pro = new ProcesosVo();
                pro.setTipo(res.getString("Tipo"));
                pro.setValor(res.getInt("Valor"));
                retorno.add(pro);
            }
            res.close();
            conex.desconectar();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, no se conecto");
            System.out.println(e);
        }
        return retorno;
    }
}
