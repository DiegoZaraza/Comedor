/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica.vo;

/**
 *
 * @author e10417a
 */
public class TipoCategoriaVo {
    private Integer idTipoCategoria;
    private String NombreTipoCat;

    public Integer getIdTipoCategoria() {
        return idTipoCategoria;
    }

    public String getNombreTipoCat() {
        return NombreTipoCat;
    }

    public void setIdTipoCategoria(Integer idTipoCategoria) {
        this.idTipoCategoria = idTipoCategoria;
    }

    public void setNombreTipoCat(String NombreTipoCat) {
        this.NombreTipoCat = NombreTipoCat;
    }    
}
