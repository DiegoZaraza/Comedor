/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathiasbattistella.share;

/**
 *
 * @author user6
 */
public class Error extends Exception{

    public Error() {
    }

    public Error(String string) {
        super(string);
    }
}
