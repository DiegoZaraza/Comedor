/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

/**
 *
 * @author e10417a
 */
public class ControladorVentanaPrincipal implements ActionListener {

    private final VentanaPrincipal vPri;

    public ControladorVentanaPrincipal(VentanaPrincipal aThis) {
        vPri = aThis;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        JButton boton = (JButton) e.getSource();
        String opcion = vPri.opcion;
        
        
        if (boton == vPri.getBtnEjecutar()) {
            vPri.getModelo().ejecutar(opcion);
        } 
    }
}

