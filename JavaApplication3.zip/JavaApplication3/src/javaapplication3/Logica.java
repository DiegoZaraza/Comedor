/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import com.google.gson.Gson;
import com.json.ErrorCode;
import com.json.Result;
import com.json.ValidatedRecordJson;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Logica {

    public int ejecucion(String subscriber, String fecha, String extension, String opcion) {
        Conexion conex = new Conexion();
        String cadenaGroup = "";
        String cadenaConsecutivo = "";
        String idGroup = "";
        String idCta = "";
        int count = 0;
        
                try {

                Statement estatuto = conex.getConnection().createStatement();
                ResultSet res = estatuto.executeQuery("SELECT TCODTIPCTA, TGRUPOCAMPOS FROM Icbsus WHERE TCODSUSCRIP = '" + subscriber + "'");

                while (res.next()) {
                    idGroup = res.getString("TGRUPOCAMPOS");
                    idCta = res.getString("TCODTIPCTA");
                }
                res.close();

                res = estatuto.executeQuery("SELECT * FROM CreditMasterFileGroups where idGroup = '" + idGroup + "'");

                while (res.next()) {
                    cadenaGroup = res.getString("cadena");
                }

                res.close();

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            try {

                Statement estatuto = conex.getConnection().createStatement();

                try (ResultSet res = estatuto.executeQuery("SELECT  a.value as Cadena FROM SequenceAgrementCreditMaster a, SubscriberSequenceCreditMaster s WHERE s.Value = a.sequenceCode and s.subscriberCode = '" + subscriber + "'")) {
                    while (res.next()) {
                        cadenaConsecutivo = res.getString("Cadena");
                    }
                }
                conex.desconectar();

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            String cadena = "";
            for (int i = 0; i < 65; i++) {
                if (cadenaGroup.charAt(i) == '1') {
                    cadena = cadena + "2";
                } else if (cadenaConsecutivo.charAt(i) == '1') {
                    cadena = cadena + "4";
                } else {
                    cadena = cadena + "0";
                }
            }

            String aux = cadena;

            Gson gson = new Gson();

            FileReader fr = null;
            try {
                fr = new FileReader("C:\\Users\\e10417a\\Desktop\\MAestros\\" + subscriber + "\\ConsolidadoHadoop.txt");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Logica.class.getName()).log(Level.SEVERE, null, ex);
            }
            BufferedReader br = new BufferedReader(fr);
            String linea;
            File archivo = new File("C:\\Users\\e10417a\\Desktop\\MAestros\\" + subscriber + "\\VALIOMNCR." + subscriber + "." + extension + "." + fecha + "-HA");

            FileWriter escribir = null;
            try {
                escribir = new FileWriter(archivo);
            } catch (IOException ex) {
                Logger.getLogger(Logica.class.getName()).log(Level.SEVERE, null, ex);
            }
            count = 1;
            double total = 0;
            try {
                while ((linea = br.readLine()) != null) {
                    cadena = aux;
                    System.out.println(count);
                    Result result = gson.fromJson(linea, Result.class);
                    
                    if (result != null) {
                        ValidatedRecordJson val = result.getValidatedRecordJson();
                    }

                    String encabezado = "2" + result.getValidatedRecordJson().getIdType() + result.getValidatedRecordJson().getIdNumber() + subscriber + idCta + result.getValidatedRecordJson().getAccountNumber();
                    ArrayList<Integer> errores;
                    errores = new ArrayList();

                    for (ErrorCode d : result.getErrorCodes()) {
                        errores.add(Integer.parseInt(d.getErrorCodeValue().charAt(7) + "" + d.getErrorCodeValue().charAt(8)));
                    }

                    errores = new ArrayList<Integer>(new HashSet<Integer>(errores));

                    for (Integer e : errores) {
                        cadena = changeChar(e, cadena);
                    }

                    Double score = result.getQualityScores().get(0).getScore();

                    String val = "";
                    if (score == 0) {
                        val = "000.0000";
                    } else if (score < 100) {
                        val = "0" + score + "000000000000000000000";
                        val = val.substring(0, 8);
                    } else {
                        val = ("" + score + "000000000000000000000").substring(0, 8);
                    }

                    total = total + score;

                    try {
                        escribir.write(encabezado + cadena + val + val + "\n");
                    } catch (IOException ex) {
                        Logger.getLogger(Logica.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    count++;
                }
            } catch (IOException ex) {
                Logger.getLogger(Logica.class.getName()).log(Level.SEVERE, null, ex);
            }

            double promedio = total / count;

            String ultima = "3";
            for (int i = 0; i < 103; i++) {
                ultima = ultima + "9";
            }
            String val = "";
            if (promedio == 0) {
                val = "000.0000";
            } else if (promedio < 100) {
                val = "0" + promedio + "000000000000000000000";
                val = val.substring(0, 8);
            } else {
                val = ("" + promedio + "000000000000000000000").substring(0, 8);
            }

            try {
                escribir.write(ultima + val + val);
            } catch (IOException ex) {
                Logger.getLogger(Logica.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                escribir.close();
            } catch (IOException ex) {
                Logger.getLogger(Logica.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return count;
    }

    public static String changeChar(int pos, String cadena) {
        String cadena1 = "";
        for (int i = 0; i < cadena.length(); i++) {
            if ((pos - 1) == i) {
                if (cadena.charAt(i) == '2') {
                    cadena1 = cadena1 + "1";
                } else if (cadena.charAt(i) == '4') {
                    cadena1 = cadena1 + "3";
                } else {
                    cadena1 = cadena1 + "0";
                }
            } else {
                cadena1 = cadena1 + cadena.charAt(i);
            }
        }
        return cadena1;
    }
}
