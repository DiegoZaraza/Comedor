/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import javax.swing.JOptionPane;

/**
 *
 * @author e10417a
 */
public class Modelo {

    private Logica log;
    private VentanaPrincipal vPri;
    
    public Logica getLog() {
        if (log == null)
            log = new Logica();
        return log;
    }

    public VentanaPrincipal getVPri() {
        if (vPri == null)
            vPri = new VentanaPrincipal(this);
        return vPri;
    }

    public void iniciar() {
        getVPri().setVisible(true);
    }

    public void setvPri(VentanaPrincipal vPri) {
        this.vPri = vPri;
    }
    
    public void ejecutar(String opcion){
        String subscriber = getVPri().getFieldSubsciptor().getText();
        String fecha = getVPri().getFieldFecha().getText();
        String extension = getVPri().getFieldExtension().getText();
         
        int value = getLog().ejecucion(subscriber, fecha, extension, opcion);
        
        JOptionPane.showMessageDialog(null, "Se procesaron " + value + " registros para el archivo " + subscriber + "." + fecha + "." + extension);
        
        refrescar();
    }
    
    public void refrescar(){
        getVPri().getFieldSubsciptor().setText("");
        getVPri().getFieldFecha().setText("");
        getVPri().getFieldExtension().setText("");
    }
}
