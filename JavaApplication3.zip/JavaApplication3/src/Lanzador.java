import javaapplication3.Modelo;

 public class Lanzador {

    private Modelo miApp;
    
    public Lanzador() {
        miApp = new Modelo();
        miApp.iniciar();        
    }
    
    public static void main(String[] args) {
        Lanzador lanzador = new Lanzador();
    }
}