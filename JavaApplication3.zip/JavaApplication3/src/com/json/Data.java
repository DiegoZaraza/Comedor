package com.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("SubscriberCode")
    @Expose
    private String subscriberCode;
    @SerializedName("TypeOfAccount")
    @Expose
    private String typeOfAccount;
    @SerializedName("endDate")
    @Expose
    private String endDate;
    @SerializedName("fileExtension")
    @Expose
    private String fileExtension;
    @SerializedName("thouInd")
    @Expose
    private String thouInd;

    public String getSubscriberCode() {
        return subscriberCode;
    }

    public void setSubscriberCode(String subscriberCode) {
        this.subscriberCode = subscriberCode;
    }

    public String getTypeOfAccount() {
        return typeOfAccount;
    }

    public void setTypeOfAccount(String typeOfAccount) {
        this.typeOfAccount = typeOfAccount;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getFileExtension() {
        return fileExtension;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    public String getThouInd() {
        return thouInd;
    }

    public void setThouInd(String thouInd) {
        this.thouInd = thouInd;
    }

}
