package com.json;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Result {

    @SerializedName("asOfDate")
    @Expose
    private Integer asOfDate;
    @SerializedName("didCreateAsOfDateFromReceivedDate")
    @Expose
    private Boolean didCreateAsOfDateFromReceivedDate;
    @SerializedName("errorCodes")
    @Expose
    private List<ErrorCode> errorCodes = null;
    @SerializedName("eventId")
    @Expose
    private Double eventId;
    @SerializedName("eventType")
    @Expose
    private Integer eventType;
    @SerializedName("lineage")
    @Expose
    private Lineage lineage;
    @SerializedName("minFrequency")
    @Expose
    private MinFrequency minFrequency;
    @SerializedName("payload")
    @Expose
    private Payload payload;
    @SerializedName("qualityScores")
    @Expose
    private List<QualityScore> qualityScores = null;
    @SerializedName("subscriberRelation")
    @Expose
    private String subscriberRelation;
    @SerializedName("validatedRecordJson")
    @Expose
    private ValidatedRecordJson validatedRecordJson;

    public Integer getAsOfDate() {
        return asOfDate;
    }

    public void setAsOfDate(Integer asOfDate) {
        this.asOfDate = asOfDate;
    }

    public Boolean getDidCreateAsOfDateFromReceivedDate() {
        return didCreateAsOfDateFromReceivedDate;
    }

    public void setDidCreateAsOfDateFromReceivedDate(Boolean didCreateAsOfDateFromReceivedDate) {
        this.didCreateAsOfDateFromReceivedDate = didCreateAsOfDateFromReceivedDate;
    }

    public List<ErrorCode> getErrorCodes() {
        return errorCodes;
    }

    public void setErrorCodes(List<ErrorCode> errorCodes) {
        this.errorCodes = errorCodes;
    }

    public Double getEventId() {
        return eventId;
    }

    public void setEventId(Double eventId) {
        this.eventId = eventId;
    }

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    public Lineage getLineage() {
        return lineage;
    }

    public void setLineage(Lineage lineage) {
        this.lineage = lineage;
    }

    public MinFrequency getMinFrequency() {
        return minFrequency;
    }

    public void setMinFrequency(MinFrequency minFrequency) {
        this.minFrequency = minFrequency;
    }

    public Payload getPayload() {
        return payload;
    }

    public void setPayload(Payload payload) {
        this.payload = payload;
    }

    public List<QualityScore> getQualityScores() {
        return qualityScores;
    }

    public void setQualityScores(List<QualityScore> qualityScores) {
        this.qualityScores = qualityScores;
    }

    public String getSubscriberRelation() {
        return subscriberRelation;
    }

    public void setSubscriberRelation(String subscriberRelation) {
        this.subscriberRelation = subscriberRelation;
    }

    public ValidatedRecordJson getValidatedRecordJson() {
        return validatedRecordJson;
    }

    public void setValidatedRecordJson(ValidatedRecordJson validatedRecordJson) {
        this.validatedRecordJson = validatedRecordJson;
    }

}
