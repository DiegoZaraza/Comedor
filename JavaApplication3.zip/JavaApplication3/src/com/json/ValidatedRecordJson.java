package com.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;



public class ValidatedRecordJson {

    @SerializedName("accOpeningDate")
    @Expose
    private String accOpeningDate;
    @SerializedName("accountNumber")
    @Expose
    private String accountNumber;
    @SerializedName("accountStatus")
    @Expose
    private String accountStatus;
    @SerializedName("additionalEvent")
    @Expose
    private String additionalEvent;
    @SerializedName("adjective")
    @Expose
    private String adjective;
    @SerializedName("adjectiveDate")
    @Expose
    private String adjectiveDate;
    @SerializedName("automationSequence")
    @Expose
    private String automationSequence;
    @SerializedName("availableBalance")
    @Expose
    private String availableBalance;
    @SerializedName("balanceOverdue")
    @Expose
    private String balanceOverdue;
    @SerializedName("cardClass")
    @Expose
    private String cardClass;
    @SerializedName("cardNumber")
    @Expose
    private String cardNumber;
    @SerializedName("cityOfFiling")
    @Expose
    private String cityOfFiling;
    @SerializedName("cityOfResidenceOrCommercialEstablishment")
    @Expose
    private String cityOfResidenceOrCommercialEstablishment;
    @SerializedName("cityOfWork")
    @Expose
    private String cityOfWork;
    @SerializedName("currencyType")
    @Expose
    private String currencyType;
    @SerializedName("daneCodeCityOfWork")
    @Expose
    private String daneCodeCityOfWork;
    @SerializedName("daneCodeForCityOfFiling")
    @Expose
    private String daneCodeForCityOfFiling;
    @SerializedName("daneCodeForCityOfResidenceOrCommercialEstablishment")
    @Expose
    private String daneCodeForCityOfResidenceOrCommercialEstablishment;
    @SerializedName("daneCodeForMailingCity")
    @Expose
    private String daneCodeForMailingCity;
    @SerializedName("dateOfExpiry")
    @Expose
    private String dateOfExpiry;
    @SerializedName("dateOfMortgageSubsidy")
    @Expose
    private String dateOfMortgageSubsidy;
    @SerializedName("dateOfOriginStatus")
    @Expose
    private String dateOfOriginStatus;
    @SerializedName("dateOfStatusOfAccount")
    @Expose
    private String dateOfStatusOfAccount;
    @SerializedName("dateOfStatusOfPlastic")
    @Expose
    private String dateOfStatusOfPlastic;
    @SerializedName("debtBalance")
    @Expose
    private String debtBalance;
    @SerializedName("delinquencyMaturation")
    @Expose
    private String delinquencyMaturation;
    @SerializedName("departmentOfResidenceOrCommercialEstablishment")
    @Expose
    private String departmentOfResidenceOrCommercialEstablishment;
    @SerializedName("departmentOfWork")
    @Expose
    private String departmentOfWork;
    @SerializedName("detailOfGuarantee")
    @Expose
    private String detailOfGuarantee;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("event")
    @Expose
    private String event;
    @SerializedName("filingOffice")
    @Expose
    private String filingOffice;
    @SerializedName("fillerField")
    @Expose
    private String fillerField;
    @SerializedName("franchise")
    @Expose
    private String franchise;
    @SerializedName("homeAddressOrCommercialEstablishment")
    @Expose
    private String homeAddressOrCommercialEstablishment;
    @SerializedName("homePhoneOrOfficePhone")
    @Expose
    private String homePhoneOrOfficePhone;
    @SerializedName("idName")
    @Expose
    private String idName;
    @SerializedName("idNumber")
    @Expose
    private String idNumber;
    @SerializedName("idType")
    @Expose
    private String idType;
    @SerializedName("initialValueOfCreditLimit")
    @Expose
    private String initialValueOfCreditLimit;
    @SerializedName("installmentOverdue")
    @Expose
    private String installmentOverdue;
    @SerializedName("mailingAddress")
    @Expose
    private String mailingAddress;
    @SerializedName("mailingCity")
    @Expose
    private String mailingCity;
    @SerializedName("mailingDepartment")
    @Expose
    private String mailingDepartment;
    @SerializedName("mobilePhone")
    @Expose
    private String mobilePhone;
    @SerializedName("mortgageSubsidy")
    @Expose
    private String mortgageSubsidy;
    @SerializedName("officeAddress")
    @Expose
    private String officeAddress;
    @SerializedName("officePhone")
    @Expose
    private String officePhone;
    @SerializedName("originStatusOfAccounts")
    @Expose
    private String originStatusOfAccounts;
    @SerializedName("paidInstallments")
    @Expose
    private String paidInstallments;
    @SerializedName("paymentDate")
    @Expose
    private String paymentDate;
    @SerializedName("paymentDeadline")
    @Expose
    private String paymentDeadline;
    @SerializedName("paymentType")
    @Expose
    private String paymentType;
    @SerializedName("periodicityOfPayment")
    @Expose
    private String periodicityOfPayment;
    @SerializedName("permanenceClause")
    @Expose
    private String permanenceClause;
    @SerializedName("permanenceClauseDate")
    @Expose
    private String permanenceClauseDate;
    @SerializedName("privateBrandName")
    @Expose
    private String privateBrandName;
    @SerializedName("probabilityOfDefault")
    @Expose
    private String probabilityOfDefault;
    @SerializedName("rating")
    @Expose
    private String rating;
    @SerializedName("stateOfAccountHolder")
    @Expose
    private String stateOfAccountHolder;
    @SerializedName("statusOfCard")
    @Expose
    private String statusOfCard;
    @SerializedName("subscriberDestination")
    @Expose
    private String subscriberDestination;
    @SerializedName("totalOfPayments")
    @Expose
    private String totalOfPayments;
    @SerializedName("typeOfCredit")
    @Expose
    private String typeOfCredit;
    @SerializedName("typeOfDebtor")
    @Expose
    private String typeOfDebtor;
    @SerializedName("typeOfGuarantee")
    @Expose
    private String typeOfGuarantee;
    @SerializedName("typeOfRepaymentPeriod")
    @Expose
    private String typeOfRepaymentPeriod;
    @SerializedName("valueOfMonthlyPayment")
    @Expose
    private String valueOfMonthlyPayment;

    public String getAccOpeningDate() {
        return accOpeningDate;
    }

    public void setAccOpeningDate(String accOpeningDate) {
        this.accOpeningDate = accOpeningDate;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getAdditionalEvent() {
        return additionalEvent;
    }

    public void setAdditionalEvent(String additionalEvent) {
        this.additionalEvent = additionalEvent;
    }

    public String getAdjective() {
        return adjective;
    }

    public void setAdjective(String adjective) {
        this.adjective = adjective;
    }

    public String getAdjectiveDate() {
        return adjectiveDate;
    }

    public void setAdjectiveDate(String adjectiveDate) {
        this.adjectiveDate = adjectiveDate;
    }

    public String getAutomationSequence() {
        return automationSequence;
    }

    public void setAutomationSequence(String automationSequence) {
        this.automationSequence = automationSequence;
    }

    public String getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(String availableBalance) {
        this.availableBalance = availableBalance;
    }

    public String getBalanceOverdue() {
        return balanceOverdue;
    }

    public void setBalanceOverdue(String balanceOverdue) {
        this.balanceOverdue = balanceOverdue;
    }

    public String getCardClass() {
        return cardClass;
    }

    public void setCardClass(String cardClass) {
        this.cardClass = cardClass;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCityOfFiling() {
        return cityOfFiling;
    }

    public void setCityOfFiling(String cityOfFiling) {
        this.cityOfFiling = cityOfFiling;
    }

    public String getCityOfResidenceOrCommercialEstablishment() {
        return cityOfResidenceOrCommercialEstablishment;
    }

    public void setCityOfResidenceOrCommercialEstablishment(String cityOfResidenceOrCommercialEstablishment) {
        this.cityOfResidenceOrCommercialEstablishment = cityOfResidenceOrCommercialEstablishment;
    }

    public String getCityOfWork() {
        return cityOfWork;
    }

    public void setCityOfWork(String cityOfWork) {
        this.cityOfWork = cityOfWork;
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public String getDaneCodeCityOfWork() {
        return daneCodeCityOfWork;
    }

    public void setDaneCodeCityOfWork(String daneCodeCityOfWork) {
        this.daneCodeCityOfWork = daneCodeCityOfWork;
    }

    public String getDaneCodeForCityOfFiling() {
        return daneCodeForCityOfFiling;
    }

    public void setDaneCodeForCityOfFiling(String daneCodeForCityOfFiling) {
        this.daneCodeForCityOfFiling = daneCodeForCityOfFiling;
    }

    public String getDaneCodeForCityOfResidenceOrCommercialEstablishment() {
        return daneCodeForCityOfResidenceOrCommercialEstablishment;
    }

    public void setDaneCodeForCityOfResidenceOrCommercialEstablishment(String daneCodeForCityOfResidenceOrCommercialEstablishment) {
        this.daneCodeForCityOfResidenceOrCommercialEstablishment = daneCodeForCityOfResidenceOrCommercialEstablishment;
    }

    public String getDaneCodeForMailingCity() {
        return daneCodeForMailingCity;
    }

    public void setDaneCodeForMailingCity(String daneCodeForMailingCity) {
        this.daneCodeForMailingCity = daneCodeForMailingCity;
    }

    public String getDateOfExpiry() {
        return dateOfExpiry;
    }

    public void setDateOfExpiry(String dateOfExpiry) {
        this.dateOfExpiry = dateOfExpiry;
    }

    public String getDateOfMortgageSubsidy() {
        return dateOfMortgageSubsidy;
    }

    public void setDateOfMortgageSubsidy(String dateOfMortgageSubsidy) {
        this.dateOfMortgageSubsidy = dateOfMortgageSubsidy;
    }

    public String getDateOfOriginStatus() {
        return dateOfOriginStatus;
    }

    public void setDateOfOriginStatus(String dateOfOriginStatus) {
        this.dateOfOriginStatus = dateOfOriginStatus;
    }

    public String getDateOfStatusOfAccount() {
        return dateOfStatusOfAccount;
    }

    public void setDateOfStatusOfAccount(String dateOfStatusOfAccount) {
        this.dateOfStatusOfAccount = dateOfStatusOfAccount;
    }

    public String getDateOfStatusOfPlastic() {
        return dateOfStatusOfPlastic;
    }

    public void setDateOfStatusOfPlastic(String dateOfStatusOfPlastic) {
        this.dateOfStatusOfPlastic = dateOfStatusOfPlastic;
    }

    public String getDebtBalance() {
        return debtBalance;
    }

    public void setDebtBalance(String debtBalance) {
        this.debtBalance = debtBalance;
    }

    public String getDelinquencyMaturation() {
        return delinquencyMaturation;
    }

    public void setDelinquencyMaturation(String delinquencyMaturation) {
        this.delinquencyMaturation = delinquencyMaturation;
    }

    public String getDepartmentOfResidenceOrCommercialEstablishment() {
        return departmentOfResidenceOrCommercialEstablishment;
    }

    public void setDepartmentOfResidenceOrCommercialEstablishment(String departmentOfResidenceOrCommercialEstablishment) {
        this.departmentOfResidenceOrCommercialEstablishment = departmentOfResidenceOrCommercialEstablishment;
    }

    public String getDepartmentOfWork() {
        return departmentOfWork;
    }

    public void setDepartmentOfWork(String departmentOfWork) {
        this.departmentOfWork = departmentOfWork;
    }

    public String getDetailOfGuarantee() {
        return detailOfGuarantee;
    }

    public void setDetailOfGuarantee(String detailOfGuarantee) {
        this.detailOfGuarantee = detailOfGuarantee;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getFilingOffice() {
        return filingOffice;
    }

    public void setFilingOffice(String filingOffice) {
        this.filingOffice = filingOffice;
    }

    public String getFillerField() {
        return fillerField;
    }

    public void setFillerField(String fillerField) {
        this.fillerField = fillerField;
    }

    public String getFranchise() {
        return franchise;
    }

    public void setFranchise(String franchise) {
        this.franchise = franchise;
    }

    public String getHomeAddressOrCommercialEstablishment() {
        return homeAddressOrCommercialEstablishment;
    }

    public void setHomeAddressOrCommercialEstablishment(String homeAddressOrCommercialEstablishment) {
        this.homeAddressOrCommercialEstablishment = homeAddressOrCommercialEstablishment;
    }

    public String getHomePhoneOrOfficePhone() {
        return homePhoneOrOfficePhone;
    }

    public void setHomePhoneOrOfficePhone(String homePhoneOrOfficePhone) {
        this.homePhoneOrOfficePhone = homePhoneOrOfficePhone;
    }

    public String getIdName() {
        return idName;
    }

    public void setIdName(String idName) {
        this.idName = idName;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getInitialValueOfCreditLimit() {
        return initialValueOfCreditLimit;
    }

    public void setInitialValueOfCreditLimit(String initialValueOfCreditLimit) {
        this.initialValueOfCreditLimit = initialValueOfCreditLimit;
    }

    public String getInstallmentOverdue() {
        return installmentOverdue;
    }

    public void setInstallmentOverdue(String installmentOverdue) {
        this.installmentOverdue = installmentOverdue;
    }

    public String getMailingAddress() {
        return mailingAddress;
    }

    public void setMailingAddress(String mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    public String getMailingCity() {
        return mailingCity;
    }

    public void setMailingCity(String mailingCity) {
        this.mailingCity = mailingCity;
    }

    public String getMailingDepartment() {
        return mailingDepartment;
    }

    public void setMailingDepartment(String mailingDepartment) {
        this.mailingDepartment = mailingDepartment;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getMortgageSubsidy() {
        return mortgageSubsidy;
    }

    public void setMortgageSubsidy(String mortgageSubsidy) {
        this.mortgageSubsidy = mortgageSubsidy;
    }

    public String getOfficeAddress() {
        return officeAddress;
    }

    public void setOfficeAddress(String officeAddress) {
        this.officeAddress = officeAddress;
    }

    public String getOfficePhone() {
        return officePhone;
    }

    public void setOfficePhone(String officePhone) {
        this.officePhone = officePhone;
    }

    public String getOriginStatusOfAccounts() {
        return originStatusOfAccounts;
    }

    public void setOriginStatusOfAccounts(String originStatusOfAccounts) {
        this.originStatusOfAccounts = originStatusOfAccounts;
    }

    public String getPaidInstallments() {
        return paidInstallments;
    }

    public void setPaidInstallments(String paidInstallments) {
        this.paidInstallments = paidInstallments;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentDeadline() {
        return paymentDeadline;
    }

    public void setPaymentDeadline(String paymentDeadline) {
        this.paymentDeadline = paymentDeadline;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPeriodicityOfPayment() {
        return periodicityOfPayment;
    }

    public void setPeriodicityOfPayment(String periodicityOfPayment) {
        this.periodicityOfPayment = periodicityOfPayment;
    }

    public String getPermanenceClause() {
        return permanenceClause;
    }

    public void setPermanenceClause(String permanenceClause) {
        this.permanenceClause = permanenceClause;
    }

    public String getPermanenceClauseDate() {
        return permanenceClauseDate;
    }

    public void setPermanenceClauseDate(String permanenceClauseDate) {
        this.permanenceClauseDate = permanenceClauseDate;
    }

    public String getPrivateBrandName() {
        return privateBrandName;
    }

    public void setPrivateBrandName(String privateBrandName) {
        this.privateBrandName = privateBrandName;
    }

    public String getProbabilityOfDefault() {
        return probabilityOfDefault;
    }

    public void setProbabilityOfDefault(String probabilityOfDefault) {
        this.probabilityOfDefault = probabilityOfDefault;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getStateOfAccountHolder() {
        return stateOfAccountHolder;
    }

    public void setStateOfAccountHolder(String stateOfAccountHolder) {
        this.stateOfAccountHolder = stateOfAccountHolder;
    }

    public String getStatusOfCard() {
        return statusOfCard;
    }

    public void setStatusOfCard(String statusOfCard) {
        this.statusOfCard = statusOfCard;
    }

    public String getSubscriberDestination() {
        return subscriberDestination;
    }

    public void setSubscriberDestination(String subscriberDestination) {
        this.subscriberDestination = subscriberDestination;
    }

    public String getTotalOfPayments() {
        return totalOfPayments;
    }

    public void setTotalOfPayments(String totalOfPayments) {
        this.totalOfPayments = totalOfPayments;
    }

    public String getTypeOfCredit() {
        return typeOfCredit;
    }

    public void setTypeOfCredit(String typeOfCredit) {
        this.typeOfCredit = typeOfCredit;
    }

    public String getTypeOfDebtor() {
        return typeOfDebtor;
    }

    public void setTypeOfDebtor(String typeOfDebtor) {
        this.typeOfDebtor = typeOfDebtor;
    }

    public String getTypeOfGuarantee() {
        return typeOfGuarantee;
    }

    public void setTypeOfGuarantee(String typeOfGuarantee) {
        this.typeOfGuarantee = typeOfGuarantee;
    }

    public String getTypeOfRepaymentPeriod() {
        return typeOfRepaymentPeriod;
    }

    public void setTypeOfRepaymentPeriod(String typeOfRepaymentPeriod) {
        this.typeOfRepaymentPeriod = typeOfRepaymentPeriod;
    }

    public String getValueOfMonthlyPayment() {
        return valueOfMonthlyPayment;
    }

    public void setValueOfMonthlyPayment(String valueOfMonthlyPayment) {
        this.valueOfMonthlyPayment = valueOfMonthlyPayment;
    }
}
