package com.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class QualityScore {

@SerializedName("name")
@Expose
private String name;
@SerializedName("score")
@Expose
private Double score;

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public Double getScore() {
return score;
}

public void setScore(Double score) {
this.score = score;
}

}