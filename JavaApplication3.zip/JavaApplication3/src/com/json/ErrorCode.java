package com.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ErrorCode {

@SerializedName("errorCodeName")
@Expose
private String errorCodeName;
@SerializedName("errorCodeValue")
@Expose
private String errorCodeValue;
@SerializedName("errorLevel")
@Expose
private String errorLevel;
@SerializedName("messageKey")
@Expose
private String messageKey;

public String getErrorCodeName() {
return errorCodeName;
}

public void setErrorCodeName(String errorCodeName) {
this.errorCodeName = errorCodeName;
}

public String getErrorCodeValue() {
return errorCodeValue;
}

public void setErrorCodeValue(String errorCodeValue) {
this.errorCodeValue = errorCodeValue;
}

public String getErrorLevel() {
return errorLevel;
}

public void setErrorLevel(String errorLevel) {
this.errorLevel = errorLevel;
}

public String getMessageKey() {
return messageKey;
}

public void setMessageKey(String messageKey) {
this.messageKey = messageKey;
}

}