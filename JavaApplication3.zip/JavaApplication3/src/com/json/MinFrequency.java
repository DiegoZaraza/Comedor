package com.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MinFrequency {

@SerializedName("count")
@Expose
private Integer count;
@SerializedName("unit")
@Expose
private Unit unit;

public Integer getCount() {
return count;
}

public void setCount(Integer count) {
this.count = count;
}

public Unit getUnit() {
return unit;
}

public void setUnit(Unit unit) {
this.unit = unit;
}

}