package com.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Lineage {

@SerializedName("dataSource")
@Expose
private String dataSource;
@SerializedName("fileAsOfDate")
@Expose
private Integer fileAsOfDate;
@SerializedName("fileName")
@Expose
private String fileName;
@SerializedName("receivedDate")
@Expose
private Integer receivedDate;
@SerializedName("subscriber")
@Expose
private String subscriber;

public String getDataSource() {
return dataSource;
}

public void setDataSource(String dataSource) {
this.dataSource = dataSource;
}

public Integer getFileAsOfDate() {
return fileAsOfDate;
}

public void setFileAsOfDate(Integer fileAsOfDate) {
this.fileAsOfDate = fileAsOfDate;
}

public String getFileName() {
return fileName;
}

public void setFileName(String fileName) {
this.fileName = fileName;
}

public Integer getReceivedDate() {
return receivedDate;
}

public void setReceivedDate(Integer receivedDate) {
this.receivedDate = receivedDate;
}

public String getSubscriber() {
return subscriber;
}

public void setSubscriber(String subscriber) {
this.subscriber = subscriber;
}

}